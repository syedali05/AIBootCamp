# WineQuality

We are going to build a model to predict the quality of wine, based on physicochemical variables.

Predict the quality of white and red wine from the UCI Machine Learning Repository dataset, provided by Paulo Cortez, University of Minho, Guimarães, Portugal, http://www3.dsi.uminho.pt/pcortez A. Cerdeira, F. Almeida, T. Matos and J. Reis, Viticulture Commission of the Vinho Verde Region(CVRVV), Porto, Portugal 
